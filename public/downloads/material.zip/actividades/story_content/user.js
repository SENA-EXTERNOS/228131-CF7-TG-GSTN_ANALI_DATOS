function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6nPkhCj4GyI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

